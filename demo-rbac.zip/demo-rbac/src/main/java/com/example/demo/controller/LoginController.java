package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.Role;
import com.example.demo.model.User;
import com.example.demo.service.RegistrationService;
import com.example.demo.service.RoleCreationService;

@Controller
public class LoginController {

	@Autowired
	RegistrationService registrationService;

	@GetMapping("/")
	public String login(Model model) {
		model.addAttribute("user", new User());
		return "loginUser";
	}

	@GetMapping("/login")
	public String loginForm(Model model) {
		model.addAttribute("user", new User());
		return "loginUser";
	}

	@PostMapping("/login")
	public String loginSubmit(@ModelAttribute User user, Model model) {
		if (registrationService.checkUser(user)) {
			user = registrationService.getUser(user.getUsername());
			model.addAttribute("user", user);
		} else {
			model.addAttribute("user", null);
		}
		model.addAttribute("loginuser", user.getUsername());
		return "homedashboard";
	}
}
