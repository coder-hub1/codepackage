package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.Role;
import com.example.demo.model.User;
import com.example.demo.service.RegistrationService;
import com.example.demo.service.RoleCreationService;

@Controller
public class RoleController {

	@Autowired
	RoleCreationService roleCreationService;

	@Autowired
	RegistrationService registrationService;

	@GetMapping("/roles")
	public String getRole(@ModelAttribute Role role, Model model) {
		List roleList = roleCreationService.getRoles();
		model.addAttribute("rolelist", roleList);
		model.addAttribute("roleUpdate", "");
		return "createrole";
	}

	@PostMapping("/roles")
	public String createrolesubmit(@ModelAttribute Role role, Model model) {
		if (!roleCreationService.checkRole(role)) {
			roleCreationService.addRole(role);
			model.addAttribute("roleUpdateStatus", "Role created successfully!!!");
		} else {
			model.addAttribute("roleUpdateStatus", "Role already exists!!!");
		}
		List roleList = roleCreationService.getRoles();
		model.addAttribute("rolelist", roleList);
		model.addAttribute("roleUpdate", "updated");
		return "createrole";
	}
}
