package com.example.demo.model;

import java.util.List;

public class Role {

	private long id;
	private String rolename;
	private String description;
	private boolean accessRead;
	private boolean accessWrite;
	private List<ActionType> actionTypeList;
	//private List<Resource> resource;
	private Resource resource;
	
	public List<ActionType> getActionTypeList() {
		return actionTypeList;
	}

	public void setActionTypeList(List<ActionType> actionTypeList) {
		this.actionTypeList = actionTypeList;
	}

	public String getRolename() {
		return rolename;
	}

	public void setRolename(String rolename) {
		this.rolename = rolename;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public boolean isAccessRead() {
		return accessRead;
	}

	public void setAccessRead(boolean accessRead) {
		this.accessRead = accessRead;
	}

	public boolean isAccessWrite() {
		return accessWrite;
	}

	public void setAccessWrite(boolean accessWrite) {
		this.accessWrite = accessWrite;
	}


}
