package com.example.demo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.demo.model.Role;
import com.example.demo.model.User;
import com.example.demo.repository.RoleRepository;

@Service
public class RoleCreationService {

	@Autowired
	RoleRepository roleRepository;

	public void addRole(Role role) {
		roleRepository.addRole(role);
	}

	public List getRoles() {
		return roleRepository.getRoles();
	}

	public boolean checkRole(Role role) {
		return roleRepository.checkRole(role);
	}

	public boolean getRoleACRead(long role) {
		return roleRepository.getRoleACRead(role);
	}

	public boolean getRoleACWrite(long role) {
		return roleRepository.getRoleACWrite(role);
	}

	public String getRolenameforValue(long role) {
		return roleRepository.getRolenameforValue(role);
	}

}
