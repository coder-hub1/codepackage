package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.Role;
import com.example.demo.model.User;
import com.example.demo.service.RegistrationService;
import com.example.demo.service.RoleCreationService;

@Controller
public class ManageUsersController {

	@Autowired
	RegistrationService registrationService;

	@Autowired
	RoleCreationService roleCreationService;

	@GetMapping("/users")
	public String users(@RequestParam(value = "username", required = true) String username, @ModelAttribute User user,
			Model model) {
		user = registrationService.getUser(username);
		if (user != null) {
			model.addAttribute("user", user);
		}
		List<User> userlist = registrationService.getUsers();
		model.addAttribute("users", userlist);
		return "users";
	}

	@GetMapping("/users/delete")
	public String delete(@RequestParam(value = "username", required = true) String username,
			@RequestParam(value = "deleteuser", required = true) String deleteuser,@ModelAttribute User user,
			Model model) {
		user = registrationService.getUser(deleteuser);
		if (deleteuser != null) {
			registrationService.deleteUser(user);
		}
		List<User> userlist = registrationService.getUsers();
		model.addAttribute("users", userlist);
		return "redirect:?username="+username;
	}
	
	  @GetMapping("/users/edit")
	  public String register(@RequestParam(value = "username", required = true) String username, @ModelAttribute User user, Model model) {
		user = registrationService.getUser(username);
	    model.addAttribute("user", user);
	    model.addAttribute("title", "Edit User");
	    return "registeredit";
	  }


	@GetMapping("/users/roles")
	public String assignrole(@RequestParam(value = "username", required = true) String username,
			@ModelAttribute User user, Model model) {
		user = registrationService.getUser(username);
		if (user != null && user.getUsername().equals("admin")) {
			List<User> list = registrationService.getUsers();
			model.addAttribute("users", list);
			List<Role> rolelist = roleCreationService.getRoles();
			model.addAttribute("roles", rolelist);

			if (!user.getUsername().equals("admin"))
				model.addAttribute("user", null);
		} else {
			model.addAttribute("userList", null);
			model.addAttribute("user", null);
		}
		model.addAttribute("loginuser", user.getUsername());
		return "assignrole";
	}

	@PostMapping("/users/roles")
	public String assignroleSubmit(@ModelAttribute User user, Model model) {
		registrationService.updateUserManagement(user);
		user = registrationService.getUser(user.getUsername());
		model.addAttribute("user", user);
		model.addAttribute("userUpdate", "updated");
		return "assignrole";
	}

}
