package com.example.demo.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.example.demo.data.ApplicationData;
import com.example.demo.model.Role;
import com.example.demo.model.User;

@Repository
public class ResourceRepository {

	private Map<Integer, Role> map = ApplicationData.roleMap;


	public boolean checkRole(Role role) {

		for (Map.Entry<Integer, Role> entry : map.entrySet()) {
			if (role.getRolename().equalsIgnoreCase(entry.getValue().getRolename())) {
				return true;
			}
		}
		return false;
	}
	
	
}
