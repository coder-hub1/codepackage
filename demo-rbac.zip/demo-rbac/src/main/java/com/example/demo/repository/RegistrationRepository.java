package com.example.demo.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.data.ApplicationData;
import com.example.demo.model.User;

@Repository
public class RegistrationRepository {
	
	@Autowired
	RoleRepository roleRepository;
	Map<Integer, User> map = ApplicationData.userMap;
	
	public void addUser(User user) {
		map.put(map.size()+1, user);
	}

	public boolean checkUser(User user) {
		for (Map.Entry<Integer, User> entry : map.entrySet()) {
			if(user.getUsername().equalsIgnoreCase(entry.getValue().getUsername())) {
				if(user.getPassword().equals(entry.getValue().getPassword())){
					return true;
				}
			}
		}
		return false;		
	}
	
	public User getUser(String username) {
		User user = null;
		for (Map.Entry<Integer, User> entry : map.entrySet()) {
			user = entry.getValue();
			if(username.equals(user.getUsername())) {
					return user;
			}
		}
		return user;		
	}

	public List getUsers() {
		User user = null;
		List<User> list = new ArrayList();
		for (Map.Entry<Integer, User> entry : map.entrySet()) {
			if(!entry.getValue().getUsername().equals("admin"))
			list.add(entry.getValue());
		}
		return list;		
	}

	public User editUser(User editUser) {
		
		User user = null;
		for (Map.Entry<Integer, User> entry : map.entrySet()) {
			user = entry.getValue();
			if(user.getUsername().equals(editUser.getUsername()))
			{
				user.setFirstname(editUser.getFirstname());
				user.setLastname(editUser.getLastname());
				user.setEmail(editUser.getEmail());
				user.setConfirmemail(editUser.getConfirmemail());
				user.setConfirmpassword(editUser.getConfirmpassword());
				user.setUsername(editUser.getUsername());
				user.setPassword(editUser.getPassword());
				map.put(entry.getKey(), user);
				break;
			}
		}
		return user;
	}

	public boolean deleteUser(User user) {
		for (Map.Entry<Integer, User> entry : map.entrySet()) {
			if(entry.getValue().getUsername().equals(user.getUsername()))
			{
				map.remove( entry.getKey());
				return true;
			}
		}
		return false;		
	}
	
	public User updateUserManagement(User manageUser) {
		User user =null;
		boolean isAccessRead;
		boolean isAccessWrite;
		for (Map.Entry<Integer, User> entry : map.entrySet()) {
			user = entry.getValue();
			if(manageUser.getUsername().equals(user.getUsername())) {
		
				user.setRole(manageUser.getRole());
				isAccessRead = roleRepository.getRoleACRead(Long.parseLong(manageUser.getRole()));
				isAccessWrite = roleRepository.getRoleACWrite(Long.parseLong(manageUser.getRole()));
				user.setAccessRead(isAccessRead);
				user.setAccessWrite(isAccessWrite);

				user.setRolename(roleRepository.getRolenameforValue
						(Long.parseLong(manageUser.getRole())));
				
				map.put(entry.getKey(), user);
			}
		}
		return user;
	}

	
}


