package com.example.demo.model;

public class ActionType {

	private long id;
	private String actionType;
	
	public String getActionType() {
		return actionType;
	}
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	


}
