package com.example.demo.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.demo.model.Role;
import com.example.demo.model.User;

public class ApplicationData {

	public static Map<Integer, User> userMap = new HashMap();
	public static Map<Integer, Role> roleMap = new HashMap(); 

	static {
		User user = new User();
		user.setUsername("admin");
		user.setPassword("admin");
		user.setFirstname("patrick");
		user.setLastname("p");
		user.setEmail("patrick@patrick.com");
		user.setRolename("Admin");
		user.setAccessRead(true);
		user.setAccessWrite(true);
		userMap.put(1, user);
		
		Role role = new Role();
		role.setId(1);
		role.setRolename("Admin");
		role.setDescription("Admin Role");
		role.setAccessRead(true);
		role.setAccessWrite(true);
		roleMap.put(1, role);

	}
}


