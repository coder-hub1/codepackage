package com.example.demo.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.example.demo.data.ApplicationData;
import com.example.demo.model.Role;
import com.example.demo.model.User;

@Repository
public class RoleRepository {

	private Map<Integer, Role> map = ApplicationData.roleMap;

	public void addRole(Role role) {
		role.setId(map.size() + 1);
		map.put(map.size() + 1, role);
	}

	public List getRoles() {
		List<Role> list = new ArrayList();
		for (Map.Entry<Integer, Role> entry : map.entrySet()) {
			// if(!entry.getValue().getUsername().equals("admin"))
			list.add(entry.getValue());
		}
		return list;
	}

	public boolean checkRole(Role role) {

		for (Map.Entry<Integer, Role> entry : map.entrySet()) {
			if (role.getRolename().equalsIgnoreCase(entry.getValue().getRolename())) {
				return true;
			}
		}
		return false;
	}

	public boolean getRoleACRead(long role) {

		for (Map.Entry<Integer, Role> entry : map.entrySet()) {
			// if(role.equals(String.valueOf(entry.getValue().getId()))) {
			if (role == entry.getValue().getId()) {
				return entry.getValue().isAccessRead();
			}
		}
		return false;
	}

	public boolean getRoleACWrite(long role) {
		for (Map.Entry<Integer, Role> entry : map.entrySet()) {
			// if(role.equals(entry.getValue().getRolename())) {
			if (role == entry.getValue().getId()) {
				return entry.getValue().isAccessWrite();
			}
		}
		return false;
	}

	public String getRolenameforValue(long role) {
		for (Map.Entry<Integer, Role> entry : map.entrySet()) {
			// if(role.equals(entry.getValue().getRolename())) {
			if (role == entry.getValue().getId()) {
				return entry.getValue().getRolename();
			}
		}
		return "";
	}

}
