package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.User;
import com.example.demo.service.RegistrationService;

@Controller
public class RegistrationController {

	@Autowired
	RegistrationService registrationService;
	
	  @GetMapping("/register")
	  public String register(@ModelAttribute User user, Model model) {
	    model.addAttribute("user", user);
	    model.addAttribute("title", "User Registration");
	    return "register";
	  }
	  
	  @PostMapping("/register")
	  public String registerSubmit(@RequestParam(value = "action", required = true) String action,
			  @ModelAttribute User user, Model model) {
	   if(registrationService.checkUser(user) && action.equals("register")){
			model.addAttribute("addUser","updated" );
			model.addAttribute("addUserStatus","User Already Exists!!!" );
			model.addAttribute("loginuser","admin" );
		    return "registerationresult";
		}
	    if(action.equals("register")){
			registrationService.addUser(user);
			model.addAttribute("user", user);
			model.addAttribute("addUser","updated" );
			model.addAttribute("addUserStatus","User Registered Successfully!!!" );
	   }else if(action.equals("edit")){
			user = registrationService.editUser(user);
			model.addAttribute("user", user);
			model.addAttribute("addUser","updated" );
			model.addAttribute("addUserStatus","User Registered Successfully!!!" );
	   }
		model.addAttribute("loginuser","admin" );
	    return "registerationresult";
	  }
}
