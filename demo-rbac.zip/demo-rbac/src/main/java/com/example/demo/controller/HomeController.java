package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.User;
import com.example.demo.service.RegistrationService;

@Controller
public class HomeController {

	@Autowired
	RegistrationService registrationService;
	
	  @GetMapping("/home")
	  public String homedashboard(
			  @RequestParam(value = "username", required = true) String username,
			  @ModelAttribute User user, Model model) {
		  user = registrationService.getUser(username);
		  if (user != null) {
		  model.addAttribute("user", user);
		  } else {
		  model.addAttribute("user", null);
		  }
		model.addAttribute("loginuser",user.getUsername() );
	    return "homedashboard";
	  }
}
