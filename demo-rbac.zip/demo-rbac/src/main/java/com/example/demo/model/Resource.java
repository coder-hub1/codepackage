package com.example.demo.model;

public class Resource {

	private long id;
	private String resourcename;
}
