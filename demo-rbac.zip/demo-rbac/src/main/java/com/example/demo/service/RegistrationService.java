package com.example.demo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.User;
import com.example.demo.repository.RegistrationRepository;

@Service
public class RegistrationService {

	@Autowired
	RegistrationRepository registrationRepository;
	
	public void addUser(User user) {
		registrationRepository.addUser(user);
	}

	public boolean checkUser(User user) {
		return registrationRepository.checkUser(user);
	}
	
	public User getUser(String username) {

		return registrationRepository.getUser(username);
	}

	public List getUsers() {

		return registrationRepository.getUsers();
	}

	public User editUser(User editUser) {

		return registrationRepository.editUser(editUser);		
	}

	public boolean deleteUser(User user) {

		return registrationRepository.deleteUser(user);		
	}

	
	public User updateUserManagement(User manageUser) {

		return registrationRepository.updateUserManagement(manageUser);
	}
	
/*	public boolean checkPermissions(User user, Resource resource, ActionType actiontype)
	{
		
		
		from user - role - list of res - 
		from resource - 
		
		listroles -> role -> resource.actionType
		
		resource - mapped roles - iterate get mapped actions 
		
		
		
		
		
		
		
		
		
		--------------
		
	 get the role from rolemap for the resource
	 
	 List<String> roles from User
	 
	 //listrolesfor the resource = roles.stream().filter(li -> li.equals(Resource)).collect(Collectors.toList());
	 
	 listofrolees iterate the role
	 
	 role - list of resources
	 
		list
		
		----------
		
		create new resource
		Role 1(RW), Role 2 (RWD)
		
		Resource 
		
		Role1.setRe
		
		-------
		Create new resource
		
		assign role1(W) to Resource
		
		
		
		resource - ActionType (R,W) - Role role1
		
        create actionType (W) ,actionType (R) , actionType D) 
make actionTypelist 
        
create Resources 
make resourcelist

resource.setActionType(list actionType)

		role.setResourceList
		
		user.setRole(role);
		
		//-> role1.setActionTypeList(list actionType){
			
	
		} */				
}

		
		
		
		
		

	


