package com.example.demo.quartz.scheduler;

import java.util.Calendar;
import java.util.Date;
import org.quartz.SimpleTrigger;

import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.model.Task;
import com.example.demo.quartz.cron.CronExpressions;
import com.example.demo.quartz.job.MyJob;
import com.example.demo.quartz.trigger.JobTriggers;
import com.example.demo.util.Utils;

@Component
public class QuartzSchedulerForCron {

	@Autowired
	CronExpressions cronExpressions;

	@Autowired
	Utils utils;

	@Autowired
	JobTriggers jobTriggers;

	public void fireJob(String cronExp, Task taskScheduler) throws SchedulerException, InterruptedException {

		String jobKey = "";
		String jobGroup = "";
		Date startDate;
		Date endDate = null;
		String hour = "";
		String min = "";
		/*
		 * if (cronExp.equals("MON-WED")) { jobKey = "bi-WeeklyJob"; jobGroup =
		 * "weeklygroup"; } else { jobKey = "dailyJob"; jobGroup = "dailygroup"; }
		 */

		System.out.println("Current time: " + new Date());

		SimpleTrigger trigger = null;

		String startTime = taskScheduler.getStartTime();

		String strArr[] = startTime.split(":|\s");
		hour = strArr[0];
		min = strArr[1];
		if (strArr[2].equalsIgnoreCase("PM")) {

			hour = String.valueOf((Integer.valueOf(strArr[0]) + 12));
		}

		startDate = utils.getDateAndTime(hour, min);

		if (taskScheduler.getEndTime() != null && !taskScheduler.getEndTime().equals("")) {
			String endTime = taskScheduler.getEndTime();

			String strArr1[] = endTime.split(":|\s");
			String endHour = strArr1[0];
			String endMin = strArr1[1];
			if (strArr[2].equalsIgnoreCase("PM")) {
				endHour = String.valueOf((Integer.valueOf(strArr[0]) + 12));
			}

			endDate = utils.getDateAndTime(endHour, endMin);
		}

		if (taskScheduler.getEndsType().equalsIgnoreCase("after")) {
			trigger = jobTriggers.getSimpleTriggerEndAfterRepeat(startDate, taskScheduler.getRepeat(),
					taskScheduler.getJobName(), "group", taskScheduler.getType());
		}

		if (taskScheduler.getEndsType().equalsIgnoreCase("on")) {
			trigger = jobTriggers.getSimpleTriggerTillEndTime(startDate, taskScheduler.getJobName(), "group", endDate,
					taskScheduler.getType());
		}

		if (taskScheduler.getEndsType().equalsIgnoreCase("never")
				&& !taskScheduler.getEndsType().equalsIgnoreCase("0")) {
			trigger = jobTriggers.getSimpleTriggerWithRepeats(startDate, taskScheduler.getRepeat(),
					taskScheduler.getJobName(), "group", taskScheduler.getType());
		}

		if (taskScheduler.getEndsType().equalsIgnoreCase("never")
				&& taskScheduler.getEndsType().equalsIgnoreCase("0")) {
			trigger = jobTriggers.getSimpleTriggerRepeatEver(startDate, taskScheduler.getJobName(), "group",
					taskScheduler.getType());
		}

		SchedulerFactory schedFact = new org.quartz.impl.StdSchedulerFactory();
		Scheduler scheduler = schedFact.getScheduler();

		// define the job and tie it to our HelloJob class
		JobBuilder jobBuilder = JobBuilder.newJob(MyJob.class);

		JobDetail jobDetail = jobBuilder.usingJobData("example", "Quartz Scheduler")
				.withIdentity(taskScheduler.getJobName(), "group").storeDurably(true)/*.requestRecovery(true)*/.build();

		scheduler.start();
		scheduler.scheduleJob(jobDetail, trigger);

		// Tell quartz to schedule the job using our trigger
		// Fire at current time + 1 min every day
		/*
		 * if (cronExp.equals("MON-WED")) { scheduler.scheduleJob(jobDetail,
		 * cronExpressions.fireBiweeklyMONWED()); } else {
		 * scheduler.scheduleJob(jobDetail, cronExpressions.fireEveryTwoMin()); }
		 */
	}
}
