package com.example.demo.model;

public class Task {

	private String startTime;
	private String type;
	private String repeat;
	private String endsType;
	private String endsOn;
	private String jobName;
	private String endTime;

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getRepeat() {
		return repeat;
	}

	public void setRepeat(String repeat) {
		this.repeat = repeat;
	}

	public String getEndsType() {
		return endsType;
	}

	public void setEndsType(String endsType) {
		this.endsType = endsType;
	}

	public String getEndsOn() {
		return endsOn;
	}

	public void setEndsOn(String endsOn) {
		this.endsOn = endsOn;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

}
