package com.example.demo.controller;

import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Job;
import com.example.demo.service.QuartzService;

@Controller
public class QuartzController {

	@Autowired
	private QuartzService quartzService;

	@GetMapping("/jobDetail")
	public String jobDetail(@ModelAttribute Job job, Model model) throws SchedulerException, InterruptedException {

		model.addAttribute("job", job);
		return "createJob";
	}

	@PostMapping("/createJob")
	public String createJob(@ModelAttribute Job job, Model model) throws SchedulerException, InterruptedException {

		model.addAttribute("job", job);
		quartzService.createJob(job);
		return "result";
	}

}
