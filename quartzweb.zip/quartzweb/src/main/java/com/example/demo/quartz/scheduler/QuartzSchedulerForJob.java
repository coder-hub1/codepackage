package com.example.demo.quartz.scheduler;

import java.util.Calendar;
import java.util.Date;
import org.quartz.SimpleTrigger;

import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleScheduleBuilder;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.example.demo.model.Job;
import com.example.demo.quartz.job.MyJob;
import com.example.demo.quartz.trigger.JobTriggerBuilder;
import com.example.demo.util.Utils;

@Component
public class QuartzSchedulerForJob {

	@Autowired
	Utils utils;

	@Autowired
	JobTriggerBuilder jobTriggers;

	public void fireJob(Job taskScheduler) throws SchedulerException, InterruptedException {

		Date startDate = null;
		Date endDate = null;
		String hour = "";
		String min = "";
		String interval = "";
		System.out.println("Current time: " + new Date());

		SimpleTrigger trigger = null;
		if (taskScheduler.getStartTime() != null && !taskScheduler.getStartTime().equals("")) {
			startDate = utils.getDateAndTime(taskScheduler.getStartTime());
		}

		if (taskScheduler.getEndTime() != null && !taskScheduler.getEndTime().equals("")) {
			endDate = utils.getDateAndTime(taskScheduler.getEndTime());
		}

		interval = taskScheduler.getInterval();
		if (taskScheduler.getInterval() == null)
			interval = "2";

		SimpleScheduleBuilder simpleScheduleBuilder;

		if (taskScheduler.getType().equals("mins")) {
			simpleScheduleBuilder = SimpleScheduleBuilder.simpleSchedule()
					.withIntervalInMinutes((Integer.valueOf(interval)));
		} else {
			simpleScheduleBuilder = SimpleScheduleBuilder.simpleSchedule()
					.withIntervalInSeconds((Integer.valueOf(interval)));
		}

		if (taskScheduler.getEndsType().equalsIgnoreCase("after")) {
			trigger = jobTriggers.getSimpleTriggerEndAfterRepeat(startDate, taskScheduler.getRepeat(),
					simpleScheduleBuilder);
		}

		if (taskScheduler.getEndsType().equalsIgnoreCase("on")) {
			trigger = jobTriggers.getSimpleTriggerTillEndTime(startDate, endDate, simpleScheduleBuilder);
		}

		if (taskScheduler.getEndsType().equalsIgnoreCase("never")) {
			trigger = jobTriggers.getSimpleTriggerRepeatEver(startDate, simpleScheduleBuilder);
		}

		SchedulerFactory schedFact = new org.quartz.impl.StdSchedulerFactory();
		Scheduler scheduler = schedFact.getScheduler();

		// define the job and tie it to Job class
		JobBuilder jobBuilder = JobBuilder.newJob(MyJob.class);

		JobDetail jobDetail = jobBuilder.usingJobData("example", "Quartz Scheduler")
				.withIdentity(taskScheduler.getJobName(), "group").storeDurably(true).build();

		scheduler.start();
		scheduler.scheduleJob(jobDetail, trigger);
	}
}
