package com.example.demo.util;

import java.util.Calendar;
import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class Utils {

	
	
	public Date getDateAndTime(String hrs, String mins)
	{
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(new Date());
	    calendar.set(Calendar.HOUR_OF_DAY, Integer.valueOf(hrs));
	    calendar.set(Calendar.MINUTE, Integer.valueOf(mins));
	    calendar.set(Calendar.SECOND, 0);
	    calendar.set(Calendar.MILLISECOND, 0);
	    return new Date(calendar.getTimeInMillis()+ 3000);

		
	}
}
