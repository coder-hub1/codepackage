package com.example.demo.util;

import java.util.Calendar;
import java.util.Date;

import org.springframework.stereotype.Component;

@Component
public class Utils {
	
	public Date getDateAndTime(String time)
	{
		String strArr1[] = time.split(":|\s");
		String hour = strArr1[0];
		String min = strArr1[1];
		if (strArr1[2].equalsIgnoreCase("PM")) {
			hour = String.valueOf((Integer.valueOf(strArr1[0]) + 12));
		}
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(new Date());
	    calendar.set(Calendar.HOUR_OF_DAY, Integer.valueOf(hour));
	    calendar.set(Calendar.MINUTE, Integer.valueOf(min));
	    calendar.set(Calendar.SECOND, 0);
	    calendar.set(Calendar.MILLISECOND, 0);
	    return new Date(calendar.getTimeInMillis()+ 3000);
	}

}
