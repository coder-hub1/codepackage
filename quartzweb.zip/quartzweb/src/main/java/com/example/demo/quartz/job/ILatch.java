package com.example.demo.quartz.job;

@FunctionalInterface
public interface ILatch {
	void countDown();
}
