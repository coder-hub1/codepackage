package com.example.demo.quartz.trigger;

import java.util.Date;

import org.quartz.SimpleScheduleBuilder;
import org.quartz.SimpleTrigger;
import org.quartz.TriggerBuilder;
import org.springframework.stereotype.Component;

@Component
public class JobTriggerBuilder {

	public SimpleTrigger getSimpleTriggerRepeatEver(Date date, String jobKey, String group, String type) {
		SimpleTrigger trigger = null;

		if (type.equals("mins")) {
			trigger = TriggerBuilder.newTrigger()./* withIdentity(jobKey, group). */startAt(date)
					.withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInMinutes(2).repeatForever())
					.build();
		} else {
			trigger = TriggerBuilder.newTrigger()./* withIdentity(jobKey, group). */startAt(date)
					.withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(2).repeatForever())
					.build();

		}

		return trigger;
	}

	public SimpleTrigger getSimpleTriggerTillEndTime(Date date, String jobKey, String group, Date endDate,
			String type) {
		SimpleTrigger trigger = null;

		if (type.equals("mins")) {
			trigger = TriggerBuilder.newTrigger()./* withIdentity(jobKey, group). */startAt(date)
					.withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInMinutes(2)).endAt(endDate)
					.build();
		} else {
			trigger = TriggerBuilder.newTrigger()./* withIdentity(jobKey, group). */startAt(date)
					.withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(2)).endAt(endDate)
					.build();

		}

		return trigger;
	}

	public SimpleTrigger getSimpleTriggerEndAfterRepeat(Date date, String repeatCount, String jobKey, String group,
			String type) {
		SimpleTrigger trigger = null;

		if (type.equals("mins")) {
			trigger = TriggerBuilder.newTrigger().withIdentity(jobKey, group).startAt(date)
					.withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInMinutes(2)
							.withRepeatCount((Integer.valueOf(repeatCount) - 1)))
					.build();
		} else {
			trigger = TriggerBuilder.newTrigger().withIdentity(jobKey, group).startAt(date)
					.withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(2)
							.withRepeatCount((Integer.valueOf(repeatCount) - 1)))
					.build();

		}

		return trigger;
	}
}
