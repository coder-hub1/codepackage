package com.example.demo.quartz.trigger;

import java.util.Date;

import org.quartz.SimpleScheduleBuilder;
import org.quartz.SimpleTrigger;
import org.quartz.TriggerBuilder;
import org.springframework.stereotype.Component;

@Component
public class JobTriggerBuilder {

	public SimpleTrigger getSimpleTriggerRepeatEver(Date date, String jobKey, String group, String type, String interval) {
		SimpleTrigger trigger = null;

		if (type.equals("mins")) {
			trigger = TriggerBuilder.newTrigger().startAt(date)
					.withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInMinutes((Integer.valueOf(interval))).repeatForever())
					.build();
		} else {
			trigger = TriggerBuilder.newTrigger().startAt(date)
					.withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds((Integer.valueOf(interval))).repeatForever())
					.build();
		}

		return trigger;
	}

	public SimpleTrigger getSimpleTriggerTillEndTime(Date date, String jobKey, String group, Date endDate,
			String type, String interval) {
		SimpleTrigger trigger = null;

		if (type.equals("mins")) {
			trigger = TriggerBuilder.newTrigger().startAt(date)
					.withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInMinutes((Integer.valueOf(interval)))).endAt(endDate)
					.build();
		} else {
			trigger = TriggerBuilder.newTrigger().startAt(date)
					.withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds((Integer.valueOf(interval)))).endAt(endDate)
					.build();
		}

		return trigger;
	}

	public SimpleTrigger getSimpleTriggerEndAfterRepeat(Date date, String repeatCount, String jobKey, String group,
			String type, String interval) {
		SimpleTrigger trigger = null;

		if (type.equals("mins")) {
			trigger = TriggerBuilder.newTrigger().startAt(date)
					.withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInMinutes((Integer.valueOf(interval)))
							.withRepeatCount((Integer.valueOf(repeatCount) - 1)))
					.build();
		} else {
			trigger = TriggerBuilder.newTrigger().startAt(date)
					.withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds((Integer.valueOf(interval)))
							.withRepeatCount((Integer.valueOf(repeatCount) - 1)))
					.build();
		}

		return trigger;
	}
}
