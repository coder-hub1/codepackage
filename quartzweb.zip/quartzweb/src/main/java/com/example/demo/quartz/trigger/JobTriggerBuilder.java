package com.example.demo.quartz.trigger;

import java.util.Date;

import org.quartz.SimpleScheduleBuilder;
import org.quartz.SimpleTrigger;
import org.quartz.TriggerBuilder;
import org.springframework.stereotype.Component;

@Component
public class JobTriggerBuilder {

	public SimpleTrigger getSimpleTriggerRepeatEver(Date startDate, SimpleScheduleBuilder simpleSchedule) {
		SimpleTrigger trigger = null;
		trigger = TriggerBuilder.newTrigger().startAt(startDate).withSchedule(simpleSchedule.repeatForever()).build();
		return trigger;
	}

	public SimpleTrigger getSimpleTriggerTillEndTime(Date startDate, Date endDate,
			SimpleScheduleBuilder simpleSchedule) {
		SimpleTrigger trigger = null;
		trigger = TriggerBuilder.newTrigger().startAt(startDate).withSchedule(simpleSchedule).endAt(endDate).build();
		return trigger;
	}

	public SimpleTrigger getSimpleTriggerEndAfterRepeat(Date startDate, String repeatCount,
			SimpleScheduleBuilder simpleSchedule) {
		SimpleTrigger trigger = null;
		trigger = TriggerBuilder.newTrigger().startAt(startDate)
				.withSchedule(simpleSchedule.withRepeatCount((Integer.valueOf(repeatCount) - 1))).build();
		return trigger;
	}
}
