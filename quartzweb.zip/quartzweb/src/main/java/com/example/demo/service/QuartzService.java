package com.example.demo.service;

import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Task;
import com.example.demo.quartz.scheduler.QuartzSchedulerForJob;

@Service
public class QuartzService {

	@Autowired
	QuartzSchedulerForJob quartzSchedulerForCron;

	public void createJob(Task scheduler) throws SchedulerException, InterruptedException {
		
		quartzSchedulerForCron.fireJob("", scheduler);
	}

	public void createJob(String schedule, Task scheduler) throws SchedulerException, InterruptedException {
		quartzSchedulerForCron.fireJob(schedule, scheduler);
	}

}
